package dominio;

public class Produtos {

	@Override
	public String toString() {
		return "NOME: " + nome + " | " +
			   "MARCA: " + marca + " | " +
			   "PREÇO: " + preco + " | " + 
			   "VALIDADE: " + validade ;
	}

	private int id;
	private String nome;
	private String marca;
	private String preco;
	private String validade;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getPreco() {
		return preco;
	}
	public void setPreco(String preco) {
		this.preco = preco;
	}
	public String getValidade() {
		return validade;
	}
	public void setValidade(String validade) {
		this.validade = validade;
	}
	

	
}
