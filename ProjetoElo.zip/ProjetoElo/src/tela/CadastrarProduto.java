package tela;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import banco.FabricaConexao;
import dominio.Produtos;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.border.EtchedBorder;
import javax.swing.ImageIcon;

public class CadastrarProduto extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldNome;
	private JTextField textFieldMarca;
	private JTextField textFieldPreco;
	private JTextField textFieldValidade;
	private JList listarProduto;
	private Produtos usuarioEdicao;
	private JButton btnNewButtonCadastrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastrarProduto frame = new CadastrarProduto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public CadastrarProduto() throws ClassNotFoundException, SQLException {
		setTitle("Cadastro de Aluno");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 662, 529);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 128, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
				"Area de Cadastro", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(93, 55, 450, 149);
		contentPane.add(panel);
		panel.setLayout(null);

		textFieldNome = new JTextField();
		textFieldNome.setBounds(32, 62, 97, 20);
		panel.add(textFieldNome);
		textFieldNome.setColumns(10);

		textFieldMarca = new JTextField();
		textFieldMarca.setColumns(10);
		textFieldMarca.setBounds(32, 104, 97, 20);
		panel.add(textFieldMarca);

		textFieldPreco = new JTextField();
		textFieldPreco.setColumns(10);
		textFieldPreco.setBounds(149, 62, 97, 20);
		panel.add(textFieldPreco);

		textFieldValidade = new JTextField();
		textFieldValidade.setColumns(10);
		textFieldValidade.setBounds(149, 104, 97, 20);
		panel.add(textFieldValidade);

		JLabel lblNome = new JLabel("MARCA");
		lblNome.setBounds(32, 93, 58, 14);
		panel.add(lblNome);

		JLabel lblEmail = new JLabel("PREÇO");
		lblEmail.setBounds(159, 48, 68, 14);
		panel.add(lblEmail);

		JLabel lblUsuario = new JLabel("NOME");
		lblUsuario.setBounds(32, 48, 58, 14);
		panel.add(lblUsuario);

		JLabel lblTelefone = new JLabel("VALIDADE");
		lblTelefone.setBounds(159, 93, 56, 14);
		panel.add(lblTelefone);

		btnNewButtonCadastrar = new JButton("Cadastrar");
		btnNewButtonCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					cadastrarUsuario();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButtonCadastrar.setBounds(289, 76, 135, 23);
		panel.add(btnNewButtonCadastrar);

		JLabel lblNewLabel = new JLabel("CADASTRAR PRODUTO");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
		lblNewLabel.setBounds(125, 21, 220, 14);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(45, 215, 591, 227);
		contentPane.add(panel_1);
		panel_1.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
				"Listagem de Usuarios", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 21, 258, 200);
		panel_1.add(scrollPane);

		listarProduto = new JList();
		scrollPane.setViewportView(listarProduto);

		JButton btnNewButtonExibir = new JButton("Exibir Dados");
		btnNewButtonExibir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Produtos usuarioSelecionado = (Produtos) listarProduto.getSelectedValue();

				String msg =  "Usuario: " + usuarioSelecionado.getUsuario() +
						     "\nNome: " + usuarioSelecionado.getNome() + 
						     "\nEmail: " + usuarioSelecionado.getEmail() + 
						     "\nTelefone: " + usuarioSelecionado.getTelefone() +
						     "\nSenha: " + usuarioSelecionado.getSenha();

				ExibirMensagem(msg);

			}
		});
		btnNewButtonExibir.setBounds(306, 46, 187, 27);
		panel_1.add(btnNewButtonExibir);

		JButton btnEditarDados = new JButton("Editar Dados");
		btnEditarDados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iniciarEdicaoUsuario();
			}
		});
		btnEditarDados.setBounds(306, 101, 187, 27);
		panel_1.add(btnEditarDados);

		JButton btnNewButtonRemover = new JButton("Remover");
		btnNewButtonRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					removerDados();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButtonRemover.setBounds(306, 152, 187, 30);
		panel_1.add(btnNewButtonRemover);

		atualizarListagem();
	}

	protected void removerDados() throws ClassNotFoundException, SQLException {

		if (listarProduto.getSelectedIndex() == -1) {
			exibirMensagemErro("Selecione um usuario");
		}

		usuarioEdicao = (Produtos) listarProduto.getSelectedValue();

		Connection conexao = FabricaConexao.criarConexao();

		String sql = "DELETE FROM cadastroUsuarios WHERE ID = ?";

		PreparedStatement comando = conexao.prepareStatement(sql);

		comando.setInt(1, usuarioEdicao.getId());
		comando.executeUpdate();

		ExibirMensagem("Dados Removido");

		atualizarListagem();

		comando.close();
		conexao.close();

	}

	protected void iniciarEdicaoUsuario() {
		if (listarProduto.getSelectedIndex() == -1) {
			exibirMensagemErro("Selecione um aluno");
		}

		usuarioEdicao = (Produtos) listarProduto.getSelectedValue();
		textFieldNome.setText(usuarioEdicao.getNome());
		textFieldMarca.setText(usuarioEdicao.getUsuario());
		textFieldPreco.setText(usuarioEdicao.getEmail());
		textFieldValidade.setText(usuarioEdicao.getTelefone());
		passwordFieldSenha.setText(usuarioEdicao.getSenha());
		
		btnNewButtonCadastrar.setText("Editar Dados");

	}

	protected void ExibirMensagem(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Info", JOptionPane.INFORMATION_MESSAGE);

	}

	private void atualizarListagem() throws ClassNotFoundException, SQLException {

		Connection conexao = FabricaConexao.criarConexao();

		String sql = "SELECT * FROM cadastroUsuarios";

		PreparedStatement comando = conexao.prepareStatement(sql);

		ResultSet resultado = comando.executeQuery();

		List<Produtos> usuariosCadastrados = new ArrayList<Produtos>();

		while (resultado.next()) {
			Produtos u = new Produtos();

			u.setId(resultado.getInt("id"));
			u.setNome(resultado.getString("nome"));
			u.setUsuario(resultado.getString("usuario"));
			u.setEmail(resultado.getString("email"));
			u.setTelefone(resultado.getString("telefone"));
            u.setSenha(resultado.getString("senha"));
			
			usuariosCadastrados.add(u);
		}

		DefaultListModel<Produtos> modelo = new DefaultListModel<>();

		for (int i = 0; i < usuariosCadastrados.size(); i++) {
			Produtos a = usuariosCadastrados.get(i);
			modelo.addElement(a);
		}

		listarProduto.setModel(modelo);

		comando.close();
		conexao.close();

	}

	protected void cadastrarUsuario() throws ClassNotFoundException, SQLException {

		if (textFieldNome.getText() == null || textFieldNome.getText().isEmpty()) {
			exibirMensagemErro("Nome não pode ser vazio");
			return;
		}

		if (textFieldMarca.getText() == null || textFieldMarca.getText().isEmpty()) {
			exibirMensagemErro("Usuario não pode ser vazio");
			return;
		}

		if (textFieldPreco.getText() == null || textFieldPreco.getText().isEmpty()) {
			exibirMensagemErro("Email não pode ser vazio");
			return;
		}

		if (textFieldValidade.getText() == null || textFieldValidade.getText().isEmpty()) {
			exibirMensagemErro("Telefone não pode ser vazio");
			return;
		}
		if (passwordFieldSenha.getText() == null || passwordFieldSenha.getText().isEmpty()) {
			exibirMensagemErro("Senha não pode ser vazio");
			return;
		}

		if (btnNewButtonCadastrar.getText().equals("Cadastrar")) {

			Connection conexao = FabricaConexao.criarConexao();

			String sql = "INSERT INTO cadastroUsuarios (usuario, nome, email, telefone, senha) VALUES (?,?,?,?,?)";

			Produtos u = new Produtos();

			u.setNome(textFieldNome.getText());
			u.setUsuario(textFieldMarca.getText());
			u.setEmail(textFieldPreco.getText());
			u.setTelefone(textFieldValidade.getText());
            u.setSenha(passwordFieldSenha.getText());
			
			PreparedStatement comando = conexao.prepareStatement(sql);

			comando.setString(1, u.getUsuario());
			comando.setString(2, u.getNome());
			comando.setString(3, u.getEmail());
			comando.setString(4, u.getTelefone());
			comando.setString(5, u.getSenha());
			comando.execute();

			System.out.println("Fechando Conexão...");

			comando.close();
			conexao.close();

			JOptionPane.showMessageDialog(null, "Usuário foi cadastrado com sucesso", "Info",
					JOptionPane.INFORMATION_MESSAGE);

		} else if (btnNewButtonCadastrar.getText().equals("Editar Dados")) {

			Connection conexao = FabricaConexao.criarConexao();

			usuarioEdicao.setNome(textFieldNome.getText());
			usuarioEdicao.setUsuario(textFieldMarca.getText());
			usuarioEdicao.setEmail(textFieldPreco.getText());
			usuarioEdicao.setTelefone(textFieldValidade.getText());
            usuarioEdicao.setSenha(passwordFieldSenha.getText());
			
			String sql = "UPDATE cadastroUsuarios SET USUARIO=?, NOME=?, EMAIL=?, TELEFONE=?, SENHA=?, WHERE ID=?";

			PreparedStatement comando = conexao.prepareStatement(sql);
			comando.setString(2, usuarioEdicao.getNome());
			comando.setString(3, usuarioEdicao.getEmail());
			comando.setString(4, usuarioEdicao.getTelefone());
			comando.setString(5, usuarioEdicao.getSenha());
			comando.setInt(6, usuarioEdicao.getId());
			comando.executeUpdate();

			ExibirMensagem("Dados Alterado");

			comando.close();
			conexao.close();

			usuarioEdicao = null;

		}

		atualizarListagem();

		textFieldNome.setText("");
		textFieldMarca.setText("");
		textFieldPreco.setText("");
		textFieldValidade.setText("");
	}

	private void exibirMensagemErro(String msg) {
		JOptionPane.showMessageDialog(null, msg, "ERRO", JOptionPane.ERROR_MESSAGE);

	}
}
